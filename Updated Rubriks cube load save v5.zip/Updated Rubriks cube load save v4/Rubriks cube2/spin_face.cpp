#include "spin_face.hpp"

spin_move::spin_move()
{
}

void spin_move::set_face(face *icube)
{
    cube = icube;
}

spin_move::~spin_move()
{
}