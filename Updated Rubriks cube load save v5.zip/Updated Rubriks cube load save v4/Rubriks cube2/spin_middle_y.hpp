#include "spin_face.hpp"

class spin_middle_y : public spin_move
{
private:
public:
    spin_middle_y();
    void make_spin(int);
    ~spin_middle_y();
};
