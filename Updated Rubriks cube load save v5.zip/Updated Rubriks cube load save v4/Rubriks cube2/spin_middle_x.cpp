#include "spin_middle_x.hpp"

spin_middle_x::spin_middle_x()
{
}
void spin_middle_x::make_spin(int dir)
{
    cube->rotate_middle_x(dir);
}
spin_middle_x::~spin_middle_x()
{
}