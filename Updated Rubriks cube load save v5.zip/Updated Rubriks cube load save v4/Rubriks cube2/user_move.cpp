#include "user_move.hpp"

user_move::user_move(face *icube)
{
    cube = icube;
}
user_move::~user_move()
{
}
void user_move::make_move(char user, int dir)
{
    if (!cube->win)
    {
        if (user == 't')
        {
            imove = new spin_top;
            imove->set_face(cube);
            imove->make_spin(dir);
        }
        else if (user == 'r')
        {
            imove = new spin_right;
            imove->set_face(cube);
            imove->make_spin(dir);
        }
        else if (user == 'l')
        {
            imove = new spin_left;
            imove->set_face(cube);
            imove->make_spin(dir);
        }
        else if (user == 'b')
        {
            imove = new spin_bottom;
            imove->set_face(cube);
            imove->make_spin(dir);
        }
        else if (user == 'y')
        {
            imove = new spin_middle_y;
            imove->set_face(cube);
            imove->make_spin(dir);
        }
        else if (user == 'x')
        {
            imove = new spin_middle_x;
            imove->set_face(cube);
            imove->make_spin(dir);
        }
    }
}