#include "spin_right.hpp"

spin_right::spin_right()
{
}
void spin_right::make_spin(int dir)
{
    cube->rotate_right(dir);
}
spin_right::~spin_right()
{
}