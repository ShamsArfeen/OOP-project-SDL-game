#include "in_game.hpp"
#include <fstream>
using namespace std;
in_game::in_game(SDL_Window *iWindow, user_move *jmove, face *icube, SDL_Renderer *jRenderer, float *x, float *y)
{
    gWindow = iWindow;
    pause_screen = SDL_LoadBMP("paused_game.bmp");
    gScreenSurface = NULL;
    gScreenSurface = SDL_GetWindowSurface(gWindow);
    screen = 0;
    imove = jmove;
    cube = icube;
    gRenderer = jRenderer;
    x_rotate = x;
    y_rotate = y;
    mouseClicked = false;
    mouse_move_flag = false;
}

in_game::~in_game()
{
}

void in_game::load_game()
{
    ifstream myfile;
    myfile.open("load.txt");
    if (myfile)
    {
        cube->clear_mat();
        int iread;
        myfile >> iread;
        cube->moves_made = iread;
        myfile >> iread;
        cube->all_surfaces = iread;
        myfile >> iread;
        int x, y, z;
        for (int i = 0; i < iread; i++)
        {
            myfile >> x;
            myfile >> y;
            myfile >> z;
            cube->add_point(x, y, z);
        }
        myfile >> iread;
        int p1, p2, p3, r, g, b;
        texture_3d col;
        for (int i = 0; i < iread; i++)
        {
            myfile >> p1;
            myfile >> p2;
            myfile >> p3;
            myfile >> r;
            myfile >> g;
            myfile >> b;
            col.r = r;
            col.g = g;
            col.b = b;
            cube->add_triangle(p1, p2, p3, col);
        }
    }
    myfile.close();
}

void in_game::save_game()
{
    ofstream myfile;
    myfile.open("load.txt");
    myfile << cube->moves_made << '\n';
    myfile << cube->all_surfaces << '\n';
    myfile << cube->point_num << '\n';
    for (int i = 0; i < cube->point_num; i++)
    {
        myfile << cube->i_point[i].x << '\n';
        myfile << cube->i_point[i].y << '\n';
        myfile << cube->i_point[i].z << '\n';
    }
    myfile << cube->triangle_num << '\n';
    for (int i = 0; i < cube->triangle_num; i++)
    {
        myfile << cube->i_triangle[i].p1 << '\n';
        myfile << cube->i_triangle[i].p2 << '\n';
        myfile << cube->i_triangle[i].p3 << '\n';
        myfile << cube->surface_color[i].r << '\n';
        myfile << cube->surface_color[i].g << '\n';
        myfile << cube->surface_color[i].b << '\n';
    }
    myfile.close();
}

int in_game::mouse_move(int x, int y)
{
    if (mouseClicked)
    {
        mouse_move_flag = true;
        if (screen == 0)
        {
            if (180 < mouse_pre_x && mouse_pre_x < 370 && 80 < mouse_pre_y && mouse_pre_y < 280)
            {
                float dy = (mouse_pre_y - y);
                float dx = (mouse_pre_x - x);
                float slope = dy / dx;
                for (int i = -1; i < 2; i++)
                {
                    int dir = 2 * (dy > 0) - 1;
                    if (250 + i * 50 < mouse_pre_x && mouse_pre_x < 300 + i * 50 && abs(slope) > 5)
                    {
                        if (i == -1)
                        {
                            imove->make_move('l', dir);
                        }
                        else if (i == 0)
                        {
                            imove->make_move('x', dir);
                        }
                        else if (i == 1)
                        {
                            imove->make_move('r', dir);
                        }
                        mouse_pre_x = x;
                        mouse_pre_y = y;
                        return 0;
                    }
                    dir = 2 * (dx < 0) - 1;
                    if (190 + i * 50 < mouse_pre_y && mouse_pre_y < 240 + i * 50 && abs(slope) < 0.4)
                    {
                        if (i == -1)
                        {
                            imove->make_move('t', dir);
                        }
                        else if (i == 0)
                        {
                            imove->make_move('y', dir);
                        }
                        else if (i == 1)
                        {
                            imove->make_move('b', dir);
                        }
                        mouse_pre_x = x;
                        mouse_pre_y = y;
                        return 0;
                    }
                }
                return 0;
            }
            *x_rotate = (float)(mouse_pre_x - x) / (float)150.0;
            *y_rotate = (float)(mouse_pre_y - y) / (float)150.0;
        }
    }
    return 0;
}

int in_game::mouse_up(int x, int y)
{
    mouseClicked = false;
    if (mouse_pre_x == x && mouse_pre_y == y && mouse_move_flag == false)
    {
        if (14 < x && 368 < y && x < 60 && y < 408 && screen == 0)
        {
            screen = 1;
            SDL_BlitSurface(pause_screen, NULL, gScreenSurface, NULL);
            SDL_UpdateWindowSurface(gWindow);
            return 1;
        }
        if (497 < x && 371 < y && x < 530 && y < 402 && screen == 0)
        {
            this->save_game();
            return 0;
        }
        if (493 < x && 290 < y && x < 531 && y < 347 && screen == 0)
        {
            this->load_game();
            return 0;
        }
        if (156 < x && 220 < y && x < 266 && y < 261 && screen == 1)
        {
            screen = 0;
            return 2;
        }
        if (278 < x && 218 < y && x < 396 && y < 259 && screen == 1)
        {
            screen = 0;
            return 0;
        }
    }
    else if (screen == 0)
    {
        cube->x_rotation += *x_rotate;
        cube->y_rotation += *y_rotate;
        *x_rotate = 0;
        *y_rotate = 0;
        return 0;
    }
    return screen;
}

int in_game::mouse_down(int x, int y)
{
    mouseClicked = true;
    mouse_pre_x = x;
    mouse_pre_y = y;
    mouse_move_flag = false;
    return 0;
}