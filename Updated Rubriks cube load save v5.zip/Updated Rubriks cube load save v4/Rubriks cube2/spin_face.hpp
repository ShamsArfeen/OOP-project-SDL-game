#pragma once
#include "face.hpp"

class spin_move
{
private:
public:
    face *cube;
    spin_move();
    void set_face(face *);
    virtual void make_spin(int) = 0;
    ~spin_move();
};