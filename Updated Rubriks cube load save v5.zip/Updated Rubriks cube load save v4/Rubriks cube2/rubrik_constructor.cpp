#include "rubrik.hpp"

void rubriks_cube::square(int p1, int p2, int p3, int p4, texture_3d i_col)
{
    int i = this->point_num;
    int x1, y1, z1, x2, y2, z2;
    x1 = i_point[p3].x;
    y1 = i_point[p3].y;
    z1 = i_point[p3].z;
    x2 = i_point[p2].x;
    y2 = i_point[p2].y;
    z2 = i_point[p2].z;
    this->add_point((6 * x1 + x2) / 7, (6 * y1 + y2) / 7, (6 * z1 + z2) / 7);
    this->add_point((6 * x2 + x1) / 7, (6 * y2 + y1) / 7, (6 * z2 + z1) / 7);
    x1 = i_point[p1].x;
    y1 = i_point[p1].y;
    z1 = i_point[p1].z;
    x2 = i_point[p4].x;
    y2 = i_point[p4].y;
    z2 = i_point[p4].z;
    this->add_point((6 * x1 + x2) / 7, (6 * y1 + y2) / 7, (6 * z1 + z2) / 7);
    this->add_point((6 * x2 + x1) / 7, (6 * y2 + y1) / 7, (6 * z2 + z1) / 7);

    //this->add_triangle(i, i + 2, i + 3, i_col);
    //this->add_triangle(i + 1, i + 2, i + 3, i_col);

    texture_3d col;
    col.r = 50;
    col.g = 50;
    col.b = 50;
    this->add_triangle(p1, p3, i, col);
    this->add_triangle(p4, p3, i, col);
    this->add_triangle(p1, p2, i + 1, col);
    this->add_triangle(p4, p2, i + 1, col);
    this->add_triangle(i, p1, i + 2, col);
    this->add_triangle(i + 1, p1, i + 2, col);
    this->add_triangle(i, p4, i + 3, col);
    this->add_triangle(i + 1, p4, i + 3, col);

    i = this->point_num;
    x1 = i_point[p3].x;
    y1 = i_point[p3].y;
    z1 = i_point[p3].z;
    x2 = i_point[p2].x;
    y2 = i_point[p2].y;
    z2 = i_point[p2].z;
    this->add_point((5 * x1 + x2) / 6, (5 * y1 + y2) / 6, (5 * z1 + z2) / 6);
    this->add_point((5 * x2 + x1) / 6, (5 * y2 + y1) / 6, (5 * z2 + z1) / 6);
    x1 = i_point[p1].x;
    y1 = i_point[p1].y;
    z1 = i_point[p1].z;
    x2 = i_point[p4].x;
    y2 = i_point[p4].y;
    z2 = i_point[p4].z;
    this->add_point((5 * x1 + x2) / 6, (5 * y1 + y2) / 6, (5 * z1 + z2) / 6);
    this->add_point((5 * x2 + x1) / 6, (5 * y2 + y1) / 6, (5 * z2 + z1) / 6);
    this->add_triangle(i, i + 2, i + 3, i_col);
    this->add_triangle(i + 1, i + 2, i + 3, i_col);
}

rubriks_cube::rubriks_cube()
{
}

void rubriks_cube::restart()
{
    moves_made = 0;
    this->clear_mat();
    this->win = false;
    //xyz axis

    /*this->add_point(1, 0, 0);
    this->add_point(0, 1, 0);
    this->add_point(0, 0, 1);*/
    point_3d px(1, 0, 0);
    *this + px;
    point_3d py(0, 1, 0);
    *this + py;
    point_3d pz(0, 0, 1);
    *this + pz;

    texture_3d i_col;
    i_col.r = 255;
    i_col.g = 255;
    i_col.b = 0;

    int sqr = 60;
    //yellow

    this->add_point(-100, sqr / 2, sqr / 2);
    this->add_point(-100, -sqr / 2, sqr / 2);
    this->add_point(-100, sqr / 2, -sqr / 2);
    this->add_point(-100, -sqr / 2, -sqr / 2);

    //this->add_triangle(point_num - 1, point_num - 2, point_num - 3, i_col);
    //this->add_triangle(point_num - 4, point_num - 3, point_num - 2, i_col);
    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, 100, 100);
    this->add_point(-100, (100 - sqr), 100);
    this->add_point(-100, 100, (100 - sqr));
    this->add_point(-100, (100 - sqr), (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, -100, 100);
    this->add_point(-100, -(100 - sqr), 100);
    this->add_point(-100, -100, (100 - sqr));
    this->add_point(-100, -(100 - sqr), (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, 100, -100);
    this->add_point(-100, (100 - sqr), -100);
    this->add_point(-100, 100, -(100 - sqr));
    this->add_point(-100, (100 - sqr), -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, -100, -100);
    this->add_point(-100, -(100 - sqr), -100);
    this->add_point(-100, -100, -(100 - sqr));
    this->add_point(-100, -(100 - sqr), -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, sqr / 2, 100);
    this->add_point(-100, -sqr / 2, 100);
    this->add_point(-100, sqr / 2, (100 - sqr));
    this->add_point(-100, -sqr / 2, (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, 100, sqr / 2);
    this->add_point(-100, (100 - sqr), sqr / 2);
    this->add_point(-100, 100, -sqr / 2);
    this->add_point(-100, (100 - sqr), -sqr / 2);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, -100, sqr / 2);
    this->add_point(-100, -(100 - sqr), sqr / 2);
    this->add_point(-100, -100, -sqr / 2);
    this->add_point(-100, -(100 - sqr), -sqr / 2);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, sqr / 2, -100);
    this->add_point(-100, -sqr / 2, -100);
    this->add_point(-100, sqr / 2, -(100 - sqr));
    this->add_point(-100, -sqr / 2, -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    i_col.r = 0;
    i_col.g = 255;
    i_col.b = 0;
    //green
    this->add_point(sqr / 2, -100, sqr / 2);
    this->add_point(sqr / 2, -100, -sqr / 2);
    this->add_point(-sqr / 2, -100, sqr / 2);
    this->add_point(-sqr / 2, -100, -sqr / 2);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, -100, 100);
    this->add_point(100, -100, (100 - sqr));
    this->add_point((100 - sqr), -100, 100);
    this->add_point((100 - sqr), -100, (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, -100, -100);
    this->add_point(100, -100, -(100 - sqr));
    this->add_point((100 - sqr), -100, -100);
    this->add_point((100 - sqr), -100, -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, -100, 100);
    this->add_point(-100, -100, (100 - sqr));
    this->add_point(-(100 - sqr), -100, 100);
    this->add_point(-(100 - sqr), -100, (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, -100, -100);
    this->add_point(-100, -100, -(100 - sqr));
    this->add_point(-(100 - sqr), -100, -100);
    this->add_point(-(100 - sqr), -100, -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, -100, sqr / 2);
    this->add_point(100, -100, -sqr / 2);
    this->add_point((100 - sqr), -100, sqr / 2);
    this->add_point((100 - sqr), -100, -sqr / 2);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(sqr / 2, -100, 100);
    this->add_point(sqr / 2, -100, (100 - sqr));
    this->add_point(-sqr / 2, -100, 100);
    this->add_point(-sqr / 2, -100, (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(sqr / 2, -100, -100);
    this->add_point(sqr / 2, -100, -(100 - sqr));
    this->add_point(-sqr / 2, -100, -100);
    this->add_point(-sqr / 2, -100, -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, -100, sqr / 2);
    this->add_point(-100, -100, -sqr / 2);
    this->add_point(-(100 - sqr), -100, sqr / 2);
    this->add_point(-(100 - sqr), -100, -sqr / 2);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    i_col.r = 255;
    i_col.g = 0;
    i_col.b = 0;
    //red
    this->add_point(100, sqr / 2, sqr / 2);
    this->add_point(100, -sqr / 2, sqr / 2);
    this->add_point(100, sqr / 2, -sqr / 2);
    this->add_point(100, -sqr / 2, -sqr / 2);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, 100, 100);
    this->add_point(100, (100 - sqr), 100);
    this->add_point(100, 100, (100 - sqr));
    this->add_point(100, (100 - sqr), (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, -100, 100);
    this->add_point(100, -(100 - sqr), 100);
    this->add_point(100, -100, (100 - sqr));
    this->add_point(100, -(100 - sqr), (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, 100, -100);
    this->add_point(100, (100 - sqr), -100);
    this->add_point(100, 100, -(100 - sqr));
    this->add_point(100, (100 - sqr), -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, -100, -100);
    this->add_point(100, -(100 - sqr), -100);
    this->add_point(100, -100, -(100 - sqr));
    this->add_point(100, -(100 - sqr), -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, sqr / 2, 100);
    this->add_point(100, -sqr / 2, 100);
    this->add_point(100, sqr / 2, (100 - sqr));
    this->add_point(100, -sqr / 2, (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, 100, sqr / 2);
    this->add_point(100, (100 - sqr), sqr / 2);
    this->add_point(100, 100, -sqr / 2);
    this->add_point(100, (100 - sqr), -sqr / 2);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, -100, sqr / 2);
    this->add_point(100, -(100 - sqr), sqr / 2);
    this->add_point(100, -100, -sqr / 2);
    this->add_point(100, -(100 - sqr), -sqr / 2);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, sqr / 2, -100);
    this->add_point(100, -sqr / 2, -100);
    this->add_point(100, sqr / 2, -(100 - sqr));
    this->add_point(100, -sqr / 2, -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    i_col.r = 0;
    i_col.g = 0;
    i_col.b = 255;
    //blue

    this->add_point(sqr / 2, 100, sqr / 2);
    this->add_point(sqr / 2, 100, -sqr / 2);
    this->add_point(-sqr / 2, 100, sqr / 2);
    this->add_point(-sqr / 2, 100, -sqr / 2);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, 100, 100);
    this->add_point(100, 100, (100 - sqr));
    this->add_point((100 - sqr), 100, 100);
    this->add_point((100 - sqr), 100, (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, 100, -100);
    this->add_point(100, 100, -(100 - sqr));
    this->add_point((100 - sqr), 100, -100);
    this->add_point((100 - sqr), 100, -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, 100, 100);
    this->add_point(-100, 100, (100 - sqr));
    this->add_point(-(100 - sqr), 100, 100);
    this->add_point(-(100 - sqr), 100, (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, 100, -100);
    this->add_point(-100, 100, -(100 - sqr));
    this->add_point(-(100 - sqr), 100, -100);
    this->add_point(-(100 - sqr), 100, -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, 100, sqr / 2);
    this->add_point(100, 100, -sqr / 2);
    this->add_point((100 - sqr), 100, sqr / 2);
    this->add_point((100 - sqr), 100, -sqr / 2);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(sqr / 2, 100, 100);
    this->add_point(sqr / 2, 100, (100 - sqr));
    this->add_point(-sqr / 2, 100, 100);
    this->add_point(-sqr / 2, 100, (100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(sqr / 2, 100, -100);
    this->add_point(sqr / 2, 100, -(100 - sqr));
    this->add_point(-sqr / 2, 100, -100);
    this->add_point(-sqr / 2, 100, -(100 - sqr));

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, 100, sqr / 2);
    this->add_point(-100, 100, -sqr / 2);
    this->add_point(-(100 - sqr), 100, sqr / 2);
    this->add_point(-(100 - sqr), 100, -sqr / 2);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    i_col.r = 255;
    i_col.g = 0;
    i_col.b = 255;
    //magenta

    this->add_point(sqr / 2, sqr / 2, 100);
    this->add_point(sqr / 2, -sqr / 2, 100);
    this->add_point(-sqr / 2, sqr / 2, 100);
    this->add_point(-sqr / 2, -sqr / 2, 100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, 100, 100);
    this->add_point(100, (100 - sqr), 100);
    this->add_point((100 - sqr), 100, 100);
    this->add_point((100 - sqr), (100 - sqr), 100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, -100, 100);
    this->add_point(100, -(100 - sqr), 100);
    this->add_point((100 - sqr), -100, 100);
    this->add_point((100 - sqr), -(100 - sqr), 100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, 100, 100);
    this->add_point(-100, (100 - sqr), 100);
    this->add_point(-(100 - sqr), 100, 100);
    this->add_point(-(100 - sqr), (100 - sqr), 100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, -100, 100);
    this->add_point(-100, -(100 - sqr), 100);
    this->add_point(-(100 - sqr), -100, 100);
    this->add_point(-(100 - sqr), -(100 - sqr), 100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, sqr / 2, 100);
    this->add_point(100, -sqr / 2, 100);
    this->add_point((100 - sqr), sqr / 2, 100);
    this->add_point((100 - sqr), -sqr / 2, 100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(sqr / 2, 100, 100);
    this->add_point(sqr / 2, (100 - sqr), 100);
    this->add_point(-sqr / 2, 100, 100);
    this->add_point(-sqr / 2, (100 - sqr), 100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(sqr / 2, -100, 100);
    this->add_point(sqr / 2, -(100 - sqr), 100);
    this->add_point(-sqr / 2, -100, 100);
    this->add_point(-sqr / 2, -(100 - sqr), 100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, sqr / 2, 100);
    this->add_point(-100, -sqr / 2, 100);
    this->add_point(-(100 - sqr), sqr / 2, 100);
    this->add_point(-(100 - sqr), -sqr / 2, 100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    i_col.r = 0;
    i_col.g = 255;
    i_col.b = 255;
    //cyan

    this->add_point(sqr / 2, sqr / 2, -100);
    this->add_point(sqr / 2, -sqr / 2, -100);
    this->add_point(-sqr / 2, sqr / 2, -100);
    this->add_point(-sqr / 2, -sqr / 2, -100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, 100, -100);
    this->add_point(100, (100 - sqr), -100);
    this->add_point((100 - sqr), 100, -100);
    this->add_point((100 - sqr), (100 - sqr), -100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, -100, -100);
    this->add_point(100, -(100 - sqr), -100);
    this->add_point((100 - sqr), -100, -100);
    this->add_point((100 - sqr), -(100 - sqr), -100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, 100, -100);
    this->add_point(-100, (100 - sqr), -100);
    this->add_point(-(100 - sqr), 100, -100);
    this->add_point(-(100 - sqr), (100 - sqr), -100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, -100, -100);
    this->add_point(-100, -(100 - sqr), -100);
    this->add_point(-(100 - sqr), -100, -100);
    this->add_point(-(100 - sqr), -(100 - sqr), -100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(100, sqr / 2, -100);
    this->add_point(100, -sqr / 2, -100);
    this->add_point((100 - sqr), sqr / 2, -100);
    this->add_point((100 - sqr), -sqr / 2, -100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(sqr / 2, 100, -100);
    this->add_point(sqr / 2, (100 - sqr), -100);
    this->add_point(-sqr / 2, 100, -100);
    this->add_point(-sqr / 2, (100 - sqr), -100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(sqr / 2, -100, -100);
    this->add_point(sqr / 2, -(100 - sqr), -100);
    this->add_point(-sqr / 2, -100, -100);
    this->add_point(-sqr / 2, -(100 - sqr), -100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    this->add_point(-100, sqr / 2, -100);
    this->add_point(-100, -sqr / 2, -100);
    this->add_point(-(100 - sqr), sqr / 2, -100);
    this->add_point(-(100 - sqr), -sqr / 2, -100);

    this->square(point_num - 1, point_num - 2, point_num - 3, point_num - 4, i_col);

    i_col.r = 70;
    i_col.g = 70;
    i_col.b = 70;
    //seven_segment(9, 0.7, -1, 0, 0, 0);
    for (int i = -1; i < 2; i = i + 2)
    {
        for (int x = -70; x < 100; x = x + 70)
        {
            for (int y = 70; y > -100; y = y - 70)
            {
                for (int a = 1; a < 4; a++)
                {

                    seven_segment((140 + x) / 70 + 3 * (70 - y) / 70, 0.7, i, a, x, y);
                }
            }
        }
    }
}

void rubriks_cube::seven_segment(int n, float size, int sgn, int axis, float x, float y)
{
    texture_3d i_col;
    i_col.r = 0;
    i_col.g = 0;
    i_col.b = 0;
    int i;

    float s = size;
    float h = size;

    float z = 101 * sgn;
    if (n == 4 || n == 5 || n == 6 || n == 8 || n == 9 || n == 0)
    {
        i = this->point_num;
        this->add_point(-12 * s + x, y + h * 18, z, axis);
        this->add_point(-8 * s + x, y + h * 14, z, axis);
        this->add_point(-8 * s + x, y + h * 6, z, axis);
        this->add_point(-12 * s + x, y + h * 2, z, axis);
        this->add_triangle(i, i + 1, i + 2, i_col);
        this->add_triangle(i + 3, i, i + 2, i_col);
    }
    if (n == 1 || n == 2 || n == 3 || n == 4 || n == 7 || n == 8 || n == 9 || n == 0)
    {
        i = this->point_num;
        this->add_point(12 * s + x, y + h * 18, z, axis);
        this->add_point(8 * s + x, y + h * 14, z, axis);
        this->add_point(8 * s + x, y + h * 6, z, axis);
        this->add_point(12 * s + x, y + h * 2, z, axis);
        this->add_triangle(i, i + 1, i + 2, i_col);
        this->add_triangle(i + 3, i, i + 2, i_col);
    }
    if (n == 1 || n == 3 || n == 4 || n == 5 || n == 6 || n == 7 || n == 8 || n == 9 || n == 0)
    {
        i = this->point_num;
        this->add_point(12 * s + x, y + h * -18, z, axis);
        this->add_point(8 * s + x, y + h * -14, z, axis);
        this->add_point(8 * s + x, y + h * -6, z, axis);
        this->add_point(12 * s + x, y + h * -2, z, axis);
        this->add_triangle(i, i + 1, i + 2, i_col);
        this->add_triangle(i + 3, i, i + 2, i_col);
    }
    if (n == 2 || n == 6 || n == 8 || n == 0)
    {
        i = this->point_num;
        this->add_point(-12 * s + x, y + h * -18, z, axis);
        this->add_point(-8 * s + x, y + h * -14, z, axis);
        this->add_point(-8 * s + x, y + h * -6, z, axis);
        this->add_point(-12 * s + x, y + h * -2, z, axis);
        this->add_triangle(i, i + 1, i + 2, i_col);
        this->add_triangle(i + 3, i, i + 2, i_col);
    }
    if (n == 2 || n == 3 || n == 5 || n == 6 || n == 7 || n == 8 || n == 9 || n == 0)
    {
        i = this->point_num;
        this->add_point(-10 * s + x, y + h * 20, z, axis);
        this->add_point(-6 * s + x, y + h * 16, z, axis);
        this->add_point(6 * s + x, y + h * 16, z, axis);
        this->add_point(10 * s + x, y + h * 20, z, axis);
        this->add_triangle(i, i + 1, i + 2, i_col);
        this->add_triangle(i + 3, i, i + 2, i_col);
    }
    if (n == 2 || n == 3 || n == 5 || n == 6 || n == 8 || n == 9 || n == 0)
    {
        i = this->point_num;
        this->add_point(-10 * s + x, y + h * -20, z, axis);
        this->add_point(-6 * s + x, y + h * -16, z, axis);
        this->add_point(6 * s + x, y + h * -16, z, axis);
        this->add_point(10 * s + x, y + h * -20, z, axis);
        this->add_triangle(i, i + 1, i + 2, i_col);
        this->add_triangle(i + 3, i, i + 2, i_col);
    }
    if (n == 2 || n == 3 || n == 4 || n == 5 || n == 6 || n == 8 || n == 9)
    {
        i = this->point_num;
        this->add_point(-10 * s + x, y + h * 0, z, axis);
        this->add_point(-8 * s + x, y + h * 1, z, axis);
        this->add_point(-8 * s + x, y + h * -1, z, axis);
        this->add_point(10 * s + x, y + h * 0, z, axis);
        this->add_point(8 * s + x, y + h * 1, z, axis);
        this->add_point(8 * s + x, y + h * -1, z, axis);
        this->add_triangle(i, i + 1, i + 4, i_col);
        this->add_triangle(i, i + 4, i + 3, i_col);
        this->add_triangle(i, i + 3, i + 5, i_col);
        this->add_triangle(i, i + 5, i + 2, i_col);
    }
}