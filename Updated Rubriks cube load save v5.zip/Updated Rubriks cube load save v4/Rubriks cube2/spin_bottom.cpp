#include "spin_bottom.hpp"

spin_bottom::spin_bottom()
{
}
void spin_bottom::make_spin(int dir)
{
    cube->rotate_bottom(dir);
}
spin_bottom::~spin_bottom()
{
}