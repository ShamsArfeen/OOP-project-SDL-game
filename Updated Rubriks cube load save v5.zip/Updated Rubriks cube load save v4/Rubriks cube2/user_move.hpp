#include "spin_top.hpp"
#include "spin_front.hpp"
#include "spin_bottom.hpp"
#include "spin_left.hpp"
#include "spin_right.hpp"
#include "spin_middle_x.hpp"
#include "spin_middle_y.hpp"

class user_move
{
private:
    spin_move *imove;

public:
    face *cube;
    user_move(face *);
    ~user_move();
    void make_move(char, int);
};