#include "spin_face.hpp"

class spin_front : public spin_move
{
private:
public:
    spin_front();
    void make_spin(int);
    ~spin_front();
};
