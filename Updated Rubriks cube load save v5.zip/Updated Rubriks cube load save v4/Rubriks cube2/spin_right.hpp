#include "spin_face.hpp"

class spin_right : public spin_move
{
private:
public:
    spin_right();
    void make_spin(int);
    ~spin_right();
};
