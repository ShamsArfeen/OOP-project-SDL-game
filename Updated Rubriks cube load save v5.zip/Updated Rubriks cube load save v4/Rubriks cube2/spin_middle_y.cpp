#include "spin_middle_y.hpp"

spin_middle_y::spin_middle_y()
{
}
void spin_middle_y::make_spin(int dir)
{
    cube->rotate_middle_y(dir);
}
spin_middle_y::~spin_middle_y()
{
}