#include "spin_face.hpp"

class spin_left : public spin_move
{
private:
public:
    spin_left();
    void make_spin(int);
    ~spin_left();
};
