#include "spin_front.hpp"

spin_front::spin_front()
{
}
void spin_front::make_spin(int dir)
{
    cube->rotate_front(dir);
}
spin_front::~spin_front()
{
}