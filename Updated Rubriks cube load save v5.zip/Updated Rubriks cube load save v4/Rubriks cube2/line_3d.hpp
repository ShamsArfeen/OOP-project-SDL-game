
class line_3d
{
private:
    /* data */
public:
    int p1, p2;
    line_3d();
    line_3d(int, int);
    line_3d(const line_3d &li);
    ~line_3d();
};
