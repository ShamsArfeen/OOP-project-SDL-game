#include <SDL.h>
#include <SDL_image.h>
#include "user_move.hpp"
class in_game
{
private:
    SDL_Surface *pause_screen;
    user_move *imove;
    SDL_Renderer *gRenderer;
    bool mouseClicked = false;

    bool mouse_move_flag;
    int mouse_pre_x;
    int mouse_pre_y;

    float *x_rotate;
    float *y_rotate;
    void save_game();
    void load_game();

public:
    SDL_Surface *gScreenSurface;
    SDL_Window *gWindow;
    int screen;
    in_game(SDL_Window *, user_move *, face *, SDL_Renderer *, float *, float *);
    ~in_game();
    face *cube;
    int mouse_move(int, int);
    int mouse_up(int, int);
    int mouse_down(int, int);
};