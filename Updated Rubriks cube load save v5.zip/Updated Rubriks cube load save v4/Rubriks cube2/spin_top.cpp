#include "spin_top.hpp"

spin_top::spin_top()
{
}
void spin_top::make_spin(int dir)
{
    cube->rotate_top(dir);
}
spin_top::~spin_top()
{
}