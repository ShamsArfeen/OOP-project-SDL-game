#include "spin_face.hpp"

class spin_middle_x : public spin_move
{
private:
public:
    spin_middle_x();
    void make_spin(int);
    ~spin_middle_x();
};
