#include "spin_face.hpp"

class spin_bottom : public spin_move
{
private:
public:
    spin_bottom();
    void make_spin(int);
    ~spin_bottom();
};
