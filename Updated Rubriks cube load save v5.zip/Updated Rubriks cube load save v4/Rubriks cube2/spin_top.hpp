#include "spin_face.hpp"

class spin_top : public spin_move
{
private:
public:
    spin_top();
    void make_spin(int);
    ~spin_top();
};
