#include "spin_left.hpp"

spin_left::spin_left()
{
}
void spin_left::make_spin(int dir)
{
    cube->rotate_left(dir);
}
spin_left::~spin_left()
{
}